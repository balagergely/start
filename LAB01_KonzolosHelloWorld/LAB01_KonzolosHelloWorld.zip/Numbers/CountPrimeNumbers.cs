﻿

namespace Numbers
{
    public class CountPrimeNumbers : SolutionProviderBase
    {
        private int upperlimit;

        public CountPrimeNumbers(int upperlimit)
        {
            this.upperlimit = upperlimit;
        }

        public override int CalculateSolution()
        {
            int cnt = 0;
            for (int i = 2; i<upperlimit; i++)
            {
                if (IsPrime(i))
                {
                    cnt += i;
                }
            }
            return cnt;
        }

        private bool IsPrime(int n)
        {
           for(int i=2; i<n; i++)
            {
                if (n % i == 0)
                    return false;
            }
            return true;
        }
    }

    }
