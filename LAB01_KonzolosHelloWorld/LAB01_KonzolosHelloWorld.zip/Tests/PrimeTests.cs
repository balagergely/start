﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using Numbers;

namespace Tests
{
    public class PrimeTests
    {
        [Fact]
        public void AddPrimeNumbers100Returns1060()
        {
            var d = new CountPrimeNumbers(100);
            Assert.Equal(1060, d.CalculateSolution());
        }
    }
}
